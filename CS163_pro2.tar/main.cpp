/* Hilina Awgichew CS163 Project 2. this the main program to get 
 * from the user and communicate it back to the ADT program.
 * also in main is where all the out put will perform from the 
 * functions and as requasted by the user.
 */

#include"stack.h"
#include"queue.h"

using namespace std;

int main() {
    stack my_stack; //variable defination for stack
    queue my_queue; //variable defination for queue


    char feature[20], location[20];    //statically allocated array 
    char a_feature[20], a_location[20];

    char res;
    int answer = 0;
     
    do {
        //user menu for input
        cout<<"Please enter a choise from the list " << endl;
        cout<<"1: Add to the stack a shopping list and location: " <<endl;
        cout<<"2: Remove shopping list from the stack: " <<endl;
        cout<<"3: push or add location: " <<endl;
        cout<<"4: remove location: " <<endl;
        cout<<"5: display shopping list: " <<endl;
        cout<<"6: display shopping list and location from the stack: " <<endl;
        cout<<"7: the last place visted: " <<endl;
        

        cout<<"Please enter your choise: (1-7) ";
        cin>>answer; cin.clear();
        cin.ignore(100, '\n');

        //while loop to privent invalid entry
        while(answer < 1 || answer > 7) {
            cout<<"Invalid chiose: please re-enter(1-6) ";
            cin>>answer;
            cin.ignore(100, '\n');
        }
        //switch statement for a choise
       switch(answer) {
           case 1:{ 

                create_shope * to_add = new create_shope;
                cout<<"Please enter shopping list; ";
                cin.get(a_feature, 20); cin.ignore(100, '\n');
                cout<<"Please enter location: ";
                cin.get(a_location, 20); cin.ignore(100, '\n');
                //variable for the create_queue function
                to_add -> create_queue(a_feature, a_location); // function call
                my_queue.enqueue(*to_add); //function call for the queue

                //to clear the memory
                if(to_add != NULL) {
                delete to_add;
                to_add = NULL;
                }
                  }
                    break;
           case 2:
                    //to remove item from the dequeue
                    if(my_queue.dequeue()) {
                       cout<<"After removing: " << endl;
                       my_queue.display_queue();
                   } else
                       cout<<"nothing to remove" <<endl;
                   break;
            case 3:
                   {
                       //variable for the stack 
                   create_shope * to_add = new create_shope;
                   cout<<"Please enter the item that matches your interest: ";
                   cin.get(feature, 20); cin.ignore(100, '\n');
                   cout<<"Please enter the location: ";
                   cin.get(location, 20); cin.ignore(100, '\n');
                   //function call to add to the list
                   to_add -> create_stack(feature, location);
                   my_stack.push(*to_add); //function call to add
                   //to clear the memory
                   if(to_add != NULL) {
                       delete to_add;
                       to_add = NULL;
                   }
                   }
                   break;
            case 4:
                   //to remove item from the stack
                   if(my_stack.pop()){
                       cout<<"After removing : ";
                       my_stack.display_all();
                   } else
                       cout<<"noting to remove: "<< endl;

                   break;
            case 5: 
                   //to display item from the stack
                   if(!my_stack.display_all())
                       cout<<"noting to display" <<endl;
                   break;
            case 6:
                   if(!my_queue.display_queue())
                       cout<<"Noting to display: "<<endl;
                   break;
            case 7:
                   {
                       //varuable to peek function
                    create_shope * to_top = new create_shope;
                   my_stack.peek(*to_top);
                   
                   //to clear memory
                   if(to_top != NULL) {
                       delete to_top;
                       to_top = NULL;
                   }
                   break;
                   }
       } 
       cout<<"Would like to continue(y/n) ? ";
       cin>>res;
       //loop for confermation to continue or not
    } while(res == 'y' || res == 'Y');
    return 1;
}


