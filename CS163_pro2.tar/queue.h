/** Hilina Awgichew CS163 Project2
 * this is a class file for the queue class type. there are
 * functions in this class and a rear data member.
 *
 */

#include"shopping.h"

struct q_node
{
    create_shope * loca;
    q_node * next;
};
class queue {
    public:

        queue();
        ~queue();

        int display_queue();    //TO diaplay from the queue
        int enqueue(create_shope & an_entry);   //to add to the list
        int dequeue();  //to remove from the queue
        

    private:
        //data member
        q_node * rear;

};

