/** Hilina Awgichew CS163 Project2
 * this header file is for the create class file. there
 * are functions and data members.
 *
 */
#include<iostream>
#include<cctype>
#include<cstring>

#ifndef TEXT
#define TEXT

class create_shope {
    
    public:

        create_shope();
        ~create_shope();

            //entry function for stack
            int create_stack(char * features, char * locations);
            int copy_entry(create_shope & to_copy);

            //entry function for queue
            int create_queue(char * features, char * locations);
            //to copy item in to the stack
            int copy(create_shope & to_copys);
            int match(create_shope & a_match);

            int display(); //to display everything
            int displays();
            int remove();   //destructor 

        private:
            char * feature;
            char * location;
            char * a_feature;
            char * a_location;

};

#endif
