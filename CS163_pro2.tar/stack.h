/** Hilina Awgichew CS163 Project2
 * this is the stack class and it have push pop
 * peek and display function, also in the data member there
 * are head and index
 *
 */

#include"shopping.h"

struct node
{
    create_shope * entry;
    node * next;
};

const int MAX = 5;

class stack 
{
    public:
        stack();
        ~stack();
        int display_all();  //to display all the item
        int peek(create_shope & to_top);    //to peek
        int push(create_shope & to_add); //to add to the list
        int pop();  //to remove item
    

    private:
        //data member
        node * head;
        //index
        int top_index;
        //display function to acces the data member
        int display_all(node * head);
};

